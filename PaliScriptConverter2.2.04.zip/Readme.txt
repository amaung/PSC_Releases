Readme
=====

Version 2.2.04 [Build 2021-08-30]
----------------------------------------
This version has the following new feature.

Multiple script conversion and dual-view outputs.
This feature allows users to select a source script and allows to convert to 
multiple target scripts. This feature is available in File mode only.
Target script selection dialog shows up after the source file is selected.

Selection of Target Scripts
------------------------------------
The target scripts are selected from the target script list by pressing Ctrl- 
key and mouse click on the selection. This will allow user to select
multiple scripts. Mouse click without having Ctrl-key pressed will select
only the current script and clears the other selections if they exist.

Clear All - clears all existing selections.
Proceed - Once target scripts are selected, this button will do conversions.
Cancel   - This will cancel the current operation and go back to the main
                screen.

Thai Ariyaka Script
--------------------------
For experimental purpose, Thai Ariyaka script is added using Ian James
version of Ariyaka font. Currently Ariyaka font is supported in Roman
key codes. So to key in Ariyaka letters, just use Roman keyboard and
type keys matching the phonetic sound of Ariyaka letters. For example,
type key-k for 'ka' and type shift-k (upper case k) for 'kha'.

Updates
-----------
- Myanmar Phonetic script has been improved a lot to handle more special
cases. There may be more special cases to add but the current version
covers a wide variety of nuances of Pali pronunciations.
- In Dual-View the tab separator width has been reduced 10 from 15. You will see narrower gaps.
- Lao, Lap Ortho and Lao Phonetic scripts have been updated to handle 
non-Lao characters.

Fonts
-------
Some fonts are being removed from in-memory resident to load from the
external files. Currently only the following scripts have fonts loaded from
files.
- Thai (THA), Thai Phonetic (THP), Lao (LAO), Lao Phonetic (LAP)
- Thai Ariyaka (THR), Thai Khom (THK), Tai Lanna (TAI), 
- Tai Lanxang (KLX)


