Readme
=======

Version 2.2.04 [Build 2021-09-20]
----------------------------------------
This version has the following new feature.

Modified multiple script conversion and dual-view outputs.
This feature allows users to select a source script and allows to convert to 
multiple target scripts. Multiple Script button is now added. Previous version
automatically launches Multiple Script Menu. This version opens the menu 
only when the Multiple Script button. Done button on the menu closes the 
menu and won't do the conversion. Convert button needs to be clicked to
start the process. This feature is available in File mode only.
Target script selection dialog shows up after the source file is selected.

Selection of Target Scripts
------------------------------------
The target scripts are selected from the target script list by pressing Ctrl- 
key and mouse click on the selection. This will allow user to select
multiple scripts. Mouse click without having Ctrl-key pressed will select
only the current script and clears the other selections if they exist.

Clear All - clears all existing selections.
Done     - Once target scripts are selected, this button is clicked to close
              the menu.
Cancel   - This will cancel the current operation and go back to the main
                screen.

Dual-line View Ex(tended) Menu
-------------------------------------
This menu is new in this version. This extended for Dual-line View is to 
allow the user to display dual-line views in different source and target
scripts. For example, the main source script is in Thai script and you want
to see the dual-line view in Roman and Myanmar, this is the menu you 
want to select First, you need to select the main source file written in 
some script. Next, you can do any conversions in single or multiple script
mode, or you can skip this step. Next, you select Dual-Line View Ex menu 
from View menu and select any source-target pairs you want to see the
Dual-Line views in. Then click on Proceed. This will then convert the file
into source and target scripts you selected and process into dual-line view
format.

Dual-line View vs Dual-line View Ex
------------------------------------------
The main difference is Dual-line View Ex allows you to have any pairs of
scripts in Dual-line View regardless of the scource script.

In the regular Dual-line View, the source script is what in the source file
and the target scripts can be one or more different scripts.

For example,

In Dual-line View,

Source script = THA
Target script(s) = ROM, MYA
Dual-line views will be = THA-ROM, THA-MYA

In Dual-line View Ex,

Source script = THA
Dual-line pairs = ROM-MYA, LAO-KHM
Dual-line views will be = ROM-THA, LAO-KHM

Bug Fixes
-----------
There was a bug found in loading fonts from files. The bug turned out to be
in the system library. It is related to freeing of PrivateFontCollection. A
work around has been put in to avoid freeing that object.

Updates
-----------
- Updated to Myanmar Phonetic script to handle more special cases. There 
may still be more special cases to add but the current version covers a wide 
variety of nuances of Pali pronunciations.
- In Dual-View the tab separator width has been reduced 10 from 15. You will see narrower gaps.


Fonts
-------
No new fonts added.